#ifndef INPUT_H_
#define INPUT_H_
void flush_input_buffer();
int getInt();
char getChar();
#endif
